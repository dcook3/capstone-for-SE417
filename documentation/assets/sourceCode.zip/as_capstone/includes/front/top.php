<?php require 'includes/config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="" name="">
	<meta content="" name="">

	<!-- Bootstrap CSS File -->
	<link href="include/bootstrap.css" rel="stylesheet">

	<!-- Libraries CSS Files -->
	<link href="lib/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">	
	<link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
	<link href="lib/animate/animate.min.css" rel="stylesheet">
	<link href="lib/ionicons/css/ionicons.min.css" rel="stylesheet">
	<link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
	<link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">

	<!-- Main Stylesheet File -->
	<link href="lib/css/style.css" rel="stylesheet">
    
    <title>Tiger Eats</title>