<div class="well card-footer">
  <p>
      <span class="float-right"></span>
  </p>
</div>




  </body>
  <script src="admin/assets/js/jquery.min.js"></script>
  <script src="admin/assets/js/bootstrap.min.js"></script>
  <script src="admin/assets/js/jquery.dataTables.min.js"></script>
  <script src="admin/assets/js/dataTables.bootstrap4.min.js"></script>
</html>
